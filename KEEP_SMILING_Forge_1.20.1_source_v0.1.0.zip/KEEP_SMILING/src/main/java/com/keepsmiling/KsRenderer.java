package com.keepsmiling;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Dibuja el sprite plano de cada entidad, siempre de frente a la camara. */
public class KsRenderer extends EntityRenderer<KsEntity> {
    public KsRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.0F;
    }

    private static KsType.Variant variant(KsEntity e) {
        KsType.Variant[] v = e.type.variants;
        return v[Math.max(0, Math.min(v.length - 1, e.getVariant()))];
    }

    @Override
    public ResourceLocation getTextureLocation(KsEntity entity) {
        return new ResourceLocation(KeepSmiling.MODID, "textures/entity/" + variant(entity).texture + ".png");
    }

    @Override
    public void render(KsEntity entity, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        float camYaw = Minecraft.getInstance().gameRenderer.getMainCamera().getYRot();
        int packed = entity.type.fullbright ? 15728880 : light;
        double[] q = variant(entity).quad;
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - camYaw));
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        float x0 = (float) q[0], y0 = (float) q[1], x1 = (float) q[2], y1 = (float) q[3];
        float u0 = (float) q[4], v0 = (float) q[5], u1 = (float) q[6], v1 = (float) q[7];
        vertex(vc, m, n, x0, y0, u0, v1, packed);
        vertex(vc, m, n, x1, y0, u1, v1, packed);
        vertex(vc, m, n, x1, y1, u1, v0, packed);
        vertex(vc, m, n, x0, y1, u0, v0, packed);
        pose.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float u, float v, int light) {
        vc.vertex(m, x, y, 0.0F).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
    }
}
