package com.keepsmiling;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Base de todas las entidades de Keep Smiling: un sprite plano que siempre te mira (lo dibuja el renderer),
 * invulnerable, que no desaparece sola. Cada comportamiento hereda y sobreescribe {@link #serverTick}.
 * Los tipos aun no portados usan esta clase tal cual (solo se ven).
 */
public class KsEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(KsEntity.class, EntityDataSerializers.INT);

    public final KsType type;
    private boolean started;
    private int hitCooldown;

    public KsEntity(EntityType<? extends PathfinderMob> entityType, Level level, KsType type) {
        super(entityType, level);
        this.type = type;
        this.xpReward = 0;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100.0)
                .add(Attributes.MOVEMENT_SPEED, 0.35)
                .add(Attributes.ATTACK_DAMAGE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    // ------------------------------------------------------------ datos
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
    }

    public int getVariant() { return this.entityData.get(VARIANT); }
    public void setVariant(int v) { this.entityData.set(VARIANT, v); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
    }

    // ------------------------------------------------------------ base
    @Override protected void registerGoals() { /* sin IA de vanilla: el movimiento lo hace cada comportamiento */ }
    @Override public boolean removeWhenFarAway(double distance) { return false; }
    @Override public boolean isInvulnerableTo(DamageSource source) { return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY); }
    @Override public boolean isPushable() { return false; }
    @Override public boolean canBeLeashed(Player player) { return false; }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && level() instanceof ServerLevel sl) {
            try { onGone(sl); } catch (Exception e) { /* nada */ }
        }
        super.remove(reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        ServerLevel level = (ServerLevel) level();
        try {
            if (!started) { started = true; onStart(level); }
            if (hitCooldown > 0) hitCooldown--;
            serverTick(level);
        } catch (Exception e) {
            // chunk sin cargar o jugador no valido: se reintenta en el siguiente tick
        }
    }

    /** primera vez que la entidad esta activa en el servidor. */
    protected void onStart(ServerLevel level) {}
    /** cada tick (solo servidor). */
    protected void serverTick(ServerLevel level) {}
    /** la entidad se esta quitando: parar sonidos, quitar efectos... */
    protected void onGone(ServerLevel level) {}

    // ------------------------------------------------------------ ayudas para los perseguidores
    protected ServerPlayer closest(ServerLevel level, double range) {
        return Ks.nearest(level, position(), range);
    }

    /** golpea al jugador si esta pegado (como el ataque cuerpo a cuerpo de Bedrock). */
    protected void contactDamage(ServerPlayer target, float damage, double range) {
        if (hitCooldown > 0 || !target.isAlive()) return;
        if (target.distanceToSqr(this) <= range * range) {
            target.hurt(damageSources().mobAttack(this), damage);
            hitCooldown = 10;
        }
    }

    /**
     * Un paso hacia el jugador (traduccion de moveChaser del addon): teletransporta 'speed' bloques.
     * Si walls es true, trepa 1 bloque, rompe muros de 2 o mas, rodea lo irrompible y arranca flores.
     */
    protected void chaseStep(ServerLevel level, ServerPlayer target, double speed, boolean walls) {
        double dx = target.getX() - getX(), dz = target.getZ() - getZ();
        double dist = Math.hypot(dx, dz);
        if (dist <= 0.8) return;
        double vx = dx / dist * speed, vz = dz / dist * speed;
        double tx = getX() + vx, tz = getZ() + vz;
        int fx = (int) Math.floor(tx), fz = (int) Math.floor(tz);
        int footY = (int) Math.floor(getY());
        double newY = getY();

        if (walls) {
            BlockPos atFoot = new BlockPos(fx, footY, fz);
            if (Ks.isFlower(level.getBlockState(atFoot))) level.removeBlock(atFoot, false);

            int wallHeight = 0;
            boolean unbreakable = false;
            for (int y = footY; y <= footY + 10; y++) {
                BlockPos p = new BlockPos(fx, y, fz);
                BlockState b = level.getBlockState(p);
                if (!b.isAir() && b.getFluidState().isEmpty()) {
                    if (Ks.isPassableGrass(b)) continue;
                    if (Ks.isFlower(b)) { level.removeBlock(p, false); continue; }
                    if (Ks.isUnbreakable(b)) unbreakable = true;
                    wallHeight++;
                } else break;
            }

            if (unbreakable) {
                int sx = (int) Math.floor(getX() - vz * 2), sz = (int) Math.floor(getZ() + vx * 2);
                BlockState left = level.getBlockState(new BlockPos(sx, footY, sz));
                if (left.isAir() || !Ks.isUnbreakable(left)) { tx = getX() - vz * speed; tz = getZ() + vx * speed; }
                else { tx = getX() + vz * speed; tz = getZ() - vx * speed; }
                newY = footY;
            } else if (wallHeight == 1) {
                newY = footY + 1;
            } else if (wallHeight >= 2) {
                for (int o = 0; o < wallHeight + 2; o++) Ks.destroy(level, new BlockPos(fx, footY + o, fz));
                newY = footY;
            } else {
                newY = groundY(level, fx, fz, footY, true);
            }
        } else {
            newY = groundY(level, fx, fz, footY, false);
        }
        moveTo(tx, newY, tz, getYRot(), getXRot());
        setDeltaMovement(Vec3.ZERO);
    }

    private double groundY(ServerLevel level, int x, int z, int footY, boolean skipGrass) {
        for (int y = footY + 1; y >= footY - 5; y--) {
            BlockPos p = new BlockPos(x, y, z);
            BlockState b = level.getBlockState(p);
            if (!b.isAir() && b.getFluidState().isEmpty() && !(skipGrass && Ks.isPassableGrass(b))) return y + 1;
        }
        return footY;
    }
}
