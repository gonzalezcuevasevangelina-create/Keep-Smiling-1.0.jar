package com.keepsmiling;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/**
 * Luster (luster.js): como el stalker pero se activa de lejos: si lo ves a menos de 150 bloques (o si aparece
 * de forma natural) suena watch + music, 2 s despues grita y te persigue. Desaparece a los 41 s de existir.
 */
public class LusterEntity extends KsEntity {
    private enum S { WAITING, WATCHING, CHASING }

    private S state = S.WAITING;
    private int effectTimer, lifeTimer, watchStart;
    private boolean triggered, chaseSoundPlayed;
    /** true = se activa nada mas aparecer (aparicion natural); false = hay que verlo */
    public boolean immediate;

    public LusterEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, KsType.LUSTER);
    }

    @Override
    protected void serverTick(ServerLevel level) {
        ServerPlayer target = closest(level, 4096);
        if (target == null) return;

        if (state == S.WATCHING && tickCount - watchStart >= 40) {
            state = S.CHASING;
            Ks.play(target, "luster_scream");
            setVariant(1);
            if (Ks.isSurvival(target)) {
                Ks.darkness(target, 100, 0);
                Ks.effect(target, MobEffects.NIGHT_VISION, 100, 0);
            }
        }
        if (state == S.CHASING) {
            chaseStep(level, target, 0.55, true);
            contactDamage(target, 8.0F, 1.6);
        }
        if (tickCount % 5 != 0) return;

        lifeTimer += 5;
        if (lifeTimer >= 820) {
            target.removeEffect(MobEffects.DARKNESS);
            target.removeEffect(MobEffects.NIGHT_VISION);
            discard();
            return;
        }
        double minDist = distanceTo(target);
        boolean canSee = Ks.hasLineOfSight(target, this, 1.5, true);

        if ((immediate || (minDist <= 150 && canSee)) && !triggered) {
            triggered = true;
            state = S.WATCHING;
            watchStart = tickCount;
            Ks.play(target, "luster_watch");
            Ks.play(target, "luster_music");
            Ks.actionBar(target, "§cDO NOT HIDE JUST RUN !");
        }

        if (state == S.CHASING) {
            Ks.actionBar(target, "§cDO NOT HIDE JUST RUN !");
            if (!chaseSoundPlayed) { Ks.play(target, "luster_chase"); chaseSoundPlayed = true; }
            if (Ks.isSurvival(target)) {
                if (effectTimer <= 0) {
                    Ks.darkness(target, 100, 0);
                    Ks.effect(target, MobEffects.NIGHT_VISION, 100, 0);
                    effectTimer = 6;
                } else effectTimer--;
            }
        }
    }

    @Override
    protected void onGone(ServerLevel level) {
        if (state != S.WAITING) {
            for (ServerPlayer p : level.players()) { p.removeEffect(MobEffects.DARKNESS); p.removeEffect(MobEffects.NIGHT_VISION); }
        }
        Ks.stopAll(level, "luster_watch", "luster_music", "luster_scream", "luster_chase");
    }
}
