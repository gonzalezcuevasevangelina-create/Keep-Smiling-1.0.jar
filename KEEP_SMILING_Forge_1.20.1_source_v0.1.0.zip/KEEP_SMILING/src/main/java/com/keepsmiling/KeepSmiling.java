package com.keepsmiling;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Keep Smiling (port a Forge 1.20.1 del addon de Bedrock de Azk873). */
@Mod(KeepSmiling.MODID)
public class KeepSmiling {
    public static final String MODID = "keepsmiling";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<KsType, RegistryObject<EntityType<KsEntity>>> TYPES = new EnumMap<>(KsType.class);
    public static final List<RegistryObject<Item>> EGGS = new ArrayList<>();
    public static final Map<String, RegistryObject<SoundEvent>> SOUND_MAP = new HashMap<>();

    static {
        for (KsType t : KsType.values()) {
            RegistryObject<EntityType<KsEntity>> r = ENTITIES.register(t.id, () -> EntityType.Builder
                    .<KsEntity>of((type, level) -> KsFactories.create(t, type, level), MobCategory.MONSTER)
                    .sized(t.width, t.height)
                    .clientTrackingRange(10)
                    .fireImmune()
                    .build(MODID + ":" + t.id));
            TYPES.put(t, r);
            if (!t.helper) {
                EGGS.add(ITEMS.register(t.id + "_spawn_egg",
                        () -> new ForgeSpawnEggItem(r, 0x111111, 0xAA2233, new Item.Properties())));
            }
        }
        for (String n : KsSoundNames.ALL) {
            SOUND_MAP.put(n, SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(new net.minecraft.resources.ResourceLocation(MODID, n))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("keepsmiling", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + MODID))
            .icon(() -> new ItemStack(EGGS.get(0).get()))
            .displayItems((params, output) -> EGGS.forEach(e -> output.accept(e.get())))
            .build());

    public KeepSmiling() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        SOUNDS.register(bus);
        TABS.register(bus);
    }
}
