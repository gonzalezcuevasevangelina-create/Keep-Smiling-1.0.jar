package com.keepsmiling;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * Tormentor (tormentor.js): WAIT (suena wait si estas lejos) -> en cuanto lo ves sin bloques de por medio, MUSIC (3 s)
 * -> WARN (warn + crack, 1 s quieto) -> CHASE (te persigue 1 bloque por tick durante 48 s). Una vez al dia como maximo.
 */
public class TormentorEntity extends KsEntity {
    private enum S { WAIT, MUSIC, WARN, CHASE }

    private S state = S.WAIT;
    private int waitTimer, musicTimer, warnTimer, chaseTimer, chaseSoundTimer;
    private UUID targetId;

    public TormentorEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, KsType.TORMENTOR);
    }

    /** el jugador al que acecha (lo fija el spawner; si no, el mas cercano al aparecer). */
    public void setTarget(ServerPlayer p) { targetId = p.getUUID(); }

    @Override
    protected void onStart(ServerLevel level) {
        if (targetId == null) {
            ServerPlayer p = closest(level, 4096);
            if (p == null) { discard(); return; }
            targetId = p.getUUID();
            Ks.play(p, "tormentor_wait");
        }
    }

    private ServerPlayer target(ServerLevel level) {
        return targetId == null ? null : level.getServer().getPlayerList().getPlayer(targetId);
    }

    @Override
    protected void serverTick(ServerLevel level) {
        ServerPlayer player = target(level);
        if (player == null || !player.isAlive()) { discard(); return; }

        if (state == S.CHASE) {
            chaseStep(level, player, 1.0, true);
            contactDamage(player, 20.0F, 2.2);
        }
        if (tickCount % 2 != 0) return; // maquina de estados cada 2 ticks

        double dist = Math.hypot(player.getX() - getX(), player.getZ() - getZ());
        switch (state) {
            case WAIT -> {
                if (dist > 60) {
                    waitTimer += 2;
                    if (waitTimer >= 120) { Ks.play(player, "tormentor_wait"); waitTimer = 0; }
                } else if (!blocked(level, player, dist)) {
                    state = S.MUSIC; musicTimer = 0;
                    Ks.play(player, "tormentor_music");
                }
            }
            case MUSIC -> {
                musicTimer += 2;
                if (musicTimer >= 60) {
                    state = S.WARN; warnTimer = 0;
                    setVariant(1);
                    Ks.play(player, "tormentor_warn");
                    Ks.play(player, "tormentor_crack");
                }
            }
            case WARN -> {
                warnTimer += 2;
                if (warnTimer >= 20) {
                    state = S.CHASE; chaseTimer = 0; chaseSoundTimer = 0;
                    Ks.play(player, "tormentor_chase");
                }
            }
            case CHASE -> {
                chaseTimer += 2;
                chaseSoundTimer += 2;
                Ks.darkness(player, 40, 0);
                if (chaseSoundTimer >= 120) { Ks.play(player, "tormentor_chase"); chaseSoundTimer = 0; }
                if (chaseTimer >= 960) { // 48 s: se va
                    discard();
                }
            }
        }
    }

    /** hay un bloque entre la cabeza del jugador y el tormentor */
    private boolean blocked(ServerLevel level, ServerPlayer p, double dist) {
        Vec3 eye = p.getEyePosition();
        Vec3 to = new Vec3(getX(), getY() + 1.8, getZ());
        HitResult hit = level.clip(new ClipContext(eye, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() != HitResult.Type.MISS;
    }

    @Override
    protected void onGone(ServerLevel level) {
        for (ServerPlayer p : level.players()) {
            Ks.stop(p, "tormentor_wait", "tormentor_music", "tormentor_warn", "tormentor_crack", "tormentor_chase");
            if (state == S.CHASE) p.removeEffect(MobEffects.DARKNESS);
        }
    }
}
