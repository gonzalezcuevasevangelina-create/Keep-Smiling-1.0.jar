package com.keepsmiling;

/** Generado a partir del addon de Bedrock "Keep Smiling": tamano, texturas por variante y plano de cada entidad. */
public enum KsType {
    ANDERDINGUS_DOLL("anderdingus_doll", 0.500f, 1.000f, 1, false, false, new Variant[]{v("dolls/mynameis_anderdingus", -0.87500, 0.00000, 0.75000, 1.62500, 0.00000, 0.00000, 1.00000, 1.00000)}),
    BIPEDAL_DOLL("bipedal_doll", 0.500f, 1.000f, 1, false, false, new Variant[]{v("dolls/bipedal_doll", -0.87500, 0.00000, 0.75000, 1.62500, 0.00000, 0.00000, 1.00000, 1.00000)}),
    BIPEDAL_DOOR("bipedal_door", 0.100f, 0.100f, 100, true, false, new Variant[]{v("keepsmiling/bipedal_door", -0.50000, 0.12500, 2.00000, 1.75000, 0.00000, 0.37500, 0.91300, 1.00000), v("keepsmiling/bipedal_door", -0.50000, 0.12500, 2.00000, 1.75000, 0.00000, 0.37500, 0.91300, 1.00000), v("keepsmiling/bipedal_door", -0.50000, 0.12500, 2.00000, 1.75000, 0.00000, 0.37500, 0.91300, 1.00000)}),
    BIPEDAL_DOOR_HAND("bipedal_door_hand", 0.100f, 0.100f, 1, false, true, new Variant[]{v("keepsmiling/bipedal_door_hand", -1.18750, 0.00000, 1.18750, 4.00000, 0.19727, 0.13574, 0.75586, 0.99707)}),
    BIPEDAL_HAND("bipedal_hand", 0.100f, 0.100f, 1, false, true, new Variant[]{v("keepsmiling/bipedal_hand", -0.50000, 0.12500, 1.31250, 1.93750, 0.00000, 0.00000, 0.93400, 1.00000)}),
    BIPEDAL_HAND1("bipedal_hand1", 0.100f, 0.100f, 1, false, true, new Variant[]{v("keepsmiling/bipedal_hand1", -0.50000, 0.00000, 1.31250, 1.81250, 0.06200, 0.00000, 1.00000, 0.98900)}),
    BIPEDAL_JUMPSCARE("bipedal_jumpscare", 0.600f, 1.800f, 100, true, false, new Variant[]{v("keepsmiling/bipedal_jumpscare", -2.00000, 0.00000, 2.00000, 4.00000, 0.00000, 0.00000, 1.00000, 1.00000)}),
    BIPEDAL_SEE_OUTSIDE("bipedal_see_outside", 0.100f, 0.100f, 100, true, false, new Variant[]{v("keepsmiling/bipedal_see_outside", -0.75000, -0.06250, 0.87500, 1.56250, 0.00000, 0.00000, 1.00000, 1.00000), v("keepsmiling/bipedal_see_outside", -0.75000, -0.06250, 0.87500, 1.56250, 0.00000, 0.00000, 1.00000, 1.00000)}),
    BIPEDAL_TREE("bipedal_tree", 0.100f, 0.100f, 100, true, false, new Variant[]{v("keepsmiling/bipedal_tree", -0.84375, 0.00000, 0.84375, 3.43750, 0.00000, 0.00000, 1.00000, 1.00000)}),
    DOOR_STALKER("door_stalker", 0.800f, 2.000f, 100, false, false, new Variant[]{v("keepsmiling/door_stalker", -0.50000, 0.00000, 0.50000, 1.50000, 0.00000, 0.00000, 1.00000, 1.00000)}),
    ERROR_ENTITY("error_entity", 0.600f, 1.800f, 20, false, false, new Variant[]{v("keepsmiling/error_entity", -0.68750, 0.00000, 0.62500, 4.00000, 0.00000, 0.00000, 0.23828, 0.65234)}),
    INFLUENCE("influence", 0.100f, 0.100f, 100, true, false, new Variant[]{v("keepsmiling/influence", -1.89100, 0.00000, 2.00000, 10.00000, 0.00000, 0.00000, 1.00000, 0.99948)}),
    JESTER_DOLL("jester_doll", 0.500f, 1.000f, 1, false, false, new Variant[]{v("dolls/jester_doll", -0.87500, 0.00000, 0.75000, 1.62500, 0.00000, 0.00000, 1.00000, 1.00000)}),
    LUSTER("luster", 0.700f, 2.800f, 100, true, false, new Variant[]{v("keepsmiling/luster", -3.72270, -0.14228, 3.52730, 6.17022, 0.01758, 0.00000, 1.00000, 0.82842), v("keepsmiling/luster_run", -3.72270, -0.14228, 3.52730, 6.17022, 0.01758, 0.00000, 1.00000, 0.82842)}),
    SMILER("smiler", 0.600f, 1.800f, 100, true, false, new Variant[]{v("keepsmiling/smiler", -1.06250, 0.06250, 1.31250, 3.68750, 0.00000, 0.00000, 1.00000, 0.95379)}),
    SMILER_DOLL("smiler_doll", 0.500f, 1.000f, 1, false, false, new Variant[]{v("dolls/smiler_doll", -0.87500, 0.00000, 0.75000, 1.62500, 0.00000, 0.00000, 1.00000, 1.00000)}),
    STALK_WINDOW("stalk_window", 0.600f, 1.800f, 100, true, false, new Variant[]{v("keepsmiling/stalk_window", -1.68750, 0.00000, 0.50000, 2.18750, 0.00000, 0.00889, 1.00000, 1.00000)}),
    STALKER("stalker", 0.700f, 2.800f, 100, true, false, new Variant[]{v("keepsmiling/stalker", -1.53528, -0.09157, 2.40222, 3.59593, 0.00000, 0.00098, 1.00000, 1.00000), v("keepsmiling/stalker_run", -1.53528, -0.09157, 2.40222, 3.59593, 0.00000, 0.00098, 1.00000, 1.00000)}),
    STALKER_BED("stalker_bed", 0.600f, 1.800f, 100, false, false, new Variant[]{v("keepsmiling/stalker_bed", -0.62500, 0.06250, 0.87500, 2.75000, 0.29234, 0.36475, 0.73405, 1.00000)}),
    STALKER_MINER("stalker_miner", 0.600f, 1.800f, 100, true, false, new Variant[]{v("keepsmiling/stalker_miner", -1.93750, 0.00000, 2.00000, 4.00000, 0.00000, 0.00000, 1.00000, 1.00000)}),
    STARE("stare", 0.600f, 1.800f, 100, true, false, new Variant[]{v("keepsmiling/stare", -0.64375, 0.00000, 0.75000, 2.20625, 0.00000, 0.00889, 1.00000, 1.00000)}),
    TORMENTOR("tormentor", 1.700f, 3.800f, 100, false, false, new Variant[]{v("keepsmiling/tormentor", -3.37097, -0.00232, 3.87903, 6.74768, 0.00000, 0.00000, 1.00000, 1.00000), v("keepsmiling/tormentor_run", -3.37097, -0.00232, 3.87903, 6.74768, 0.00000, 0.00000, 1.00000, 1.00000)}),
    TORMENTOR_DOLL("tormentor_doll", 0.500f, 1.000f, 1, false, false, new Variant[]{v("dolls/tormentor_doll", -0.87500, 0.00000, 0.75000, 1.62500, 0.00000, 0.00000, 1.00000, 1.00000)}),
    TORMENTOR_DOOR("tormentor_door", 0.100f, 0.100f, 99999, true, false, new Variant[]{v("keepsmiling/tormentor_door", -0.43750, 0.75000, 3.50000, 4.62500, 0.25200, 0.10100, 1.00000, 0.77600), v("keepsmiling/tormentor_window_peek", -1.31250, 0.00000, 0.56250, 1.87500, 0.00000, 0.00000, 1.00000, 1.00000), v("keepsmiling/tormentor_window_peek1", -1.31250, 0.00000, 0.56250, 1.87500, 0.00000, 0.00000, 1.00000, 1.00000)}),
    WINDOW_STALKER("window_stalker", 0.800f, 2.200f, 100, false, false, new Variant[]{v("keepsmiling/window_peek", -0.43750, 0.00000, 1.06250, 2.12500, 0.00000, 0.00000, 1.00000, 1.00000), v("keepsmiling/window_peek1", -0.43750, 0.00000, 1.06250, 2.12500, 0.00000, 0.00000, 1.00000, 1.00000), v("keepsmiling/windows_behind", -0.43750, 0.00000, 1.06250, 2.87500, 0.00000, 0.00000, 1.00000, 1.00000)});

    /** Una textura (carpeta dentro de textures/entity) y su plano: x0,y0,x1,y1 (bloques) y u0,v0,u1,v1. */
    public static final class Variant {
        public final String texture;
        public final double[] quad;
        Variant(String texture, double[] quad) { this.texture = texture; this.quad = quad; }
    }

    private static Variant v(String t, double... q) { return new Variant(t, q); }

    public final String id;
    public final float width, height;
    public final int health;
    public final boolean fullbright;   // ignore_lighting
    public final boolean helper;       // entidad auxiliar: sin huevo
    public final Variant[] variants;

    KsType(String id, float width, float height, int health, boolean fullbright, boolean helper, Variant[] variants) {
        this.id = id; this.width = width; this.height = height; this.health = health;
        this.fullbright = fullbright; this.helper = helper; this.variants = variants;
    }
}
