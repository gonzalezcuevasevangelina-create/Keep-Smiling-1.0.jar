package com.keepsmiling;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

import java.util.UUID;

/**
 * Stare (stare.js): aparece en cuevas o en bosques de noche y espera. Cuando lo miras suena stare_seen: 50 % de las
 * veces se va; si no, te persigue 90 s (a 0.88 bloques por tick, 12 de dano al tocarte) con oscuridad. Si llegas a
 * una zona bien iluminada ("RUN TO THE LIGHT !") desaparece.
 */
public class StareEntity extends KsEntity {
    private enum S { WAITING, BYE, CHASE }

    private S phase = S.WAITING;
    private int chaseTimer, runSoundTimer, byeAt;
    private UUID targetId;

    public StareEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, KsType.STARE);
    }

    public void setTarget(ServerPlayer p) { targetId = p.getUUID(); }

    private ServerPlayer target(ServerLevel level) {
        ServerPlayer t = targetId == null ? null : level.getServer().getPlayerList().getPlayer(targetId);
        return t != null && t.isAlive() ? t : closest(level, 4096);
    }

    @Override
    protected void serverTick(ServerLevel level) {
        if (phase == S.BYE) {
            if (tickCount >= byeAt) discard();
            return;
        }
        ServerPlayer target = target(level);
        if (target == null) return;

        if (phase == S.CHASE) {
            chaseStep(level, target, 0.88, false);
            contactDamage(target, 12.0F, 1.5);
        }
        if (tickCount % 2 != 0) return;

        if (phase == S.CHASE && level.getMaxLocalRawBrightness(target.blockPosition()) > 9) { // llegaste a la luz
            discard();
            return;
        }
        if (phase == S.WAITING) {
            if (seenBy(target)) {
                setVariant(1);
                Ks.play(target, "stare_seen");
                if (level.random.nextFloat() < 0.5F) {
                    phase = S.BYE;
                    byeAt = tickCount + 20;
                } else {
                    phase = S.CHASE;
                    chaseTimer = 0;
                    runSoundTimer = 0;
                    Ks.play(target, "stare_music");
                }
            }
        } else if (phase == S.CHASE) {
            chaseTimer += 2;
            runSoundTimer += 2;
            if (chaseTimer >= 1800) { discard(); return; }
            if (runSoundTimer >= 100) { Ks.play(target, "stare_run"); runSoundTimer = 0; }
            Ks.actionBar(target, "§bRUN TO THE LIGHT !");
            if (Ks.isSurvival(target)) Ks.darkness(target, 40, 0);
        }
    }

    private boolean seenBy(ServerPlayer p) {
        if (distanceTo(p) > 30) return false;
        return Ks.hasLineOfSight(p, this, 1.5, true) && Ks.lookDot(p, this, 1.5) > 0.40;
    }

    @Override
    protected void onGone(ServerLevel level) {
        if (phase == S.CHASE) {
            for (ServerPlayer p : level.players()) { p.removeEffect(MobEffects.DARKNESS); Ks.actionBar(p, ""); }
        }
        Ks.stopAll(level, "stare_music", "stare_run", "stare_seen");
    }
}
