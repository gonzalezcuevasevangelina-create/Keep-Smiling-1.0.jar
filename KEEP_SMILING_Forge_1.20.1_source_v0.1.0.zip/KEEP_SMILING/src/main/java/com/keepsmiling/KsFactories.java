package com.keepsmiling;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/** Elige la clase con el comportamiento de cada tipo. Los tipos sin clase propia son solo un sprite (aun no portados). */
public final class KsFactories {
    private KsFactories() {}

    public static KsEntity create(KsType t, EntityType<? extends PathfinderMob> type, Level level) {
        return switch (t) {
            case STALKER -> new StalkerEntity(type, level);
            case LUSTER -> new LusterEntity(type, level);
            case TORMENTOR -> new TormentorEntity(type, level);
            case SMILER -> new SmilerEntity(type, level);
            case STARE -> new StareEntity(type, level);
            default -> new KsEntity(type, level, t);
        };
    }
}
