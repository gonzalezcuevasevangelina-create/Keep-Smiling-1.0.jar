package com.keepsmiling;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Utilidades compartidas por todas las entidades de Keep Smiling. */
public final class Ks {
    private Ks() {}

    // ------------------------------------------------------------ jugadores
    public static boolean isSurvival(ServerPlayer p) {
        return !p.isCreative() && !p.isSpectator();
    }

    public static List<ServerPlayer> players(ServerLevel level) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : level.players()) if (!p.isSpectator() && p.isAlive()) out.add(p);
        return out;
    }

    public static ServerPlayer nearest(ServerLevel level, Vec3 pos, double range) {
        ServerPlayer best = null;
        double bd = range * range;
        for (ServerPlayer p : players(level)) {
            double d = p.distanceToSqr(pos);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    // ------------------------------------------------------------ sonidos (por nombre, p. ej. "stalker_watch")
    public static SoundEvent sound(String name) {
        return KeepSmiling.SOUND_MAP.get(name).get();
    }

    public static void play(ServerPlayer p, String name) {
        p.playNotifySound(sound(name), SoundSource.MASTER, 1.0F, 1.0F);
    }

    public static void playAll(ServerLevel level, String name) {
        for (ServerPlayer p : players(level)) play(p, name);
    }

    public static void stop(ServerPlayer p, String... names) {
        for (String n : names) p.connection.send(new ClientboundStopSoundPacket(new ResourceLocation(KeepSmiling.MODID, n), null));
    }

    public static void stopAll(ServerLevel level, String... names) {
        for (ServerPlayer p : level.players()) stop(p, names);
    }

    // ------------------------------------------------------------ efectos y mensajes
    public static void effect(ServerPlayer p, MobEffect e, int ticks, int amp) {
        p.addEffect(new MobEffectInstance(e, ticks, amp, false, false));
    }

    public static void darkness(ServerPlayer p, int ticks, int amp) { effect(p, MobEffects.DARKNESS, ticks, amp); }

    public static void actionBar(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    // ------------------------------------------------------------ tiempo
    /** hora del dia 0-24000 */
    public static long timeOfDay(ServerLevel level) { return level.getDayTime() % 24000L; }
    public static long day(ServerLevel level) { return level.getDayTime() / 24000L; }
    public static boolean isDay(ServerLevel level) { return timeOfDay(level) < 12000; }
    public static boolean isNightOrSunset(ServerLevel level) { long t = timeOfDay(level); return t >= 12000 && t <= 23000; }
    public static boolean isNight(ServerLevel level) { long t = timeOfDay(level); return t >= 13000 && t <= 23000; }

    public static boolean isCave(ServerLevel level, Vec3 pos) {
        BlockPos head = BlockPos.containing(pos.x, pos.y + 1, pos.z);
        return pos.y < 50 || level.getBrightness(LightLayer.SKY, head) == 0;
    }

    public static boolean canSeeSky(ServerLevel level, Vec3 pos) {
        BlockPos head = BlockPos.containing(pos.x, pos.y + 1, pos.z);
        return level.getBrightness(LightLayer.SKY, head) > 0;
    }

    // ------------------------------------------------------------ bloques
    public static String name(BlockState s) {
        ResourceLocation k = ForgeRegistries.BLOCKS.getKey(s.getBlock());
        return k == null ? "" : k.getPath();
    }

    public static boolean isFlower(BlockState s) {
        String id = name(s);
        for (String f : new String[]{"flower", "rose", "dandelion", "poppy", "orchid", "allium", "tulip", "daisy", "cornflower",
                "lily", "sunflower", "lilac", "peony", "pitcher", "torchflower"}) if (id.contains(f)) return true;
        return false;
    }

    public static boolean isPassableGrass(BlockState s) {
        String id = name(s);
        return id.contains("short_grass") || id.contains("tall_grass") || id.equals("grass")
                || (id.contains("grass") && !id.contains("block") && !id.contains("path"));
    }

    public static boolean isUnbreakable(BlockState s) {
        String id = name(s);
        return id.contains("bedrock") || id.contains("reinforced_deepslate") || id.equals("barrier")
                || id.contains("command_block");
    }

    public static boolean isSolidGround(ServerLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        return !s.isAir() && !s.getCollisionShape(level, p).isEmpty();
    }

    /** destruye el bloque (si no es irrompible) sin soltar objetos. */
    public static void destroy(ServerLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        if (!s.isAir() && !isUnbreakable(s)) level.removeBlock(p, false);
    }

    // ------------------------------------------------------------ ver / ser visto
    /** hay linea de vista entre el jugador y la entidad (el cristal, las vallas y las puertas no tapan). */
    public static boolean hasLineOfSight(ServerPlayer p, Entity e, double aboveFeet, boolean doorsTransparent) {
        Vec3 eye = p.getEyePosition();
        Vec3 to = e.position().add(0, aboveFeet, 0);
        try {
            HitResult hit = p.level().clip(new ClipContext(eye, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (hit.getType() == HitResult.Type.MISS) return true;
            BlockState s = hit instanceof net.minecraft.world.phys.BlockHitResult bhr ? p.level().getBlockState(bhr.getBlockPos()) : p.level().getBlockState(BlockPos.containing(hit.getLocation()));
            String b = name(s);
            return b.contains("glass") || b.contains("pane") || b.contains("fence") || b.contains("trapdoor") || b.contains("iron_bars")
                    || (doorsTransparent && b.contains("door"));
        } catch (Exception ex) {
            return true;
        }
    }

    /** el jugador apunta a la entidad: producto punto de su vista con la direccion hacia ella. */
    public static double lookDot(ServerPlayer p, Entity e, double aboveFeet) {
        Vec3 eye = p.getEyePosition();
        Vec3 d = e.position().add(0, aboveFeet, 0).subtract(eye);
        double len = d.length();
        if (len == 0) return 1;
        return p.getViewVector(1.0F).dot(d.scale(1.0 / len));
    }

    // ------------------------------------------------------------ terreno
    /** punto libre (suelo solido, 2 bloques de aire) en la columna x,z cerca de la altura dada; null si no hay. */
    public static Vec3 spotAt(ServerLevel level, int x, int z, int aroundY, int range) {
        for (int dy = range; dy >= -range; dy--) {
            int y = aroundY + dy;
            BlockPos below = new BlockPos(x, y - 1, z), cur = new BlockPos(x, y, z), above = new BlockPos(x, y + 1, z);
            if (!level.hasChunkAt(cur)) return null;
            if (isSolidGround(level, below) && level.getBlockState(cur).isAir() && level.getBlockState(above).isAir())
                return new Vec3(x + 0.5, y, z + 0.5);
        }
        return null;
    }

    public static Vec3 behindPlayerSpot(ServerLevel level, ServerPlayer p, double min, double max) {
        double dist = min + level.random.nextDouble() * (max - min);
        Vec3 v = p.getViewVector(1.0F);
        return spotAt(level, (int) Math.floor(p.getX() - v.x * dist), (int) Math.floor(p.getZ() - v.z * dist), (int) Math.floor(p.getY()), 4);
    }

    public static Vec3 ringSpot(ServerLevel level, ServerPlayer p, double min, double max, int vert) {
        double a = level.random.nextDouble() * Math.PI * 2;
        double dist = min + level.random.nextDouble() * (max - min);
        return spotAt(level, (int) Math.floor(p.getX() + Math.cos(a) * dist), (int) Math.floor(p.getZ() + Math.sin(a) * dist), (int) Math.floor(p.getY()), vert);
    }

    /** altura de la superficie (primer bloque no vacio de arriba hacia abajo) + 1 */
    public static int surfaceY(ServerLevel level, int x, int z) {
        BlockPos top = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
        return top.getY();
    }
}
