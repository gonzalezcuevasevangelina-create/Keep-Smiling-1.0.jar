package com.keepsmiling;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Aparicion natural (traduccion de los "maybeSpawn..." del addon) y limpieza cuando el jugador muere. */
@Mod.EventBusSubscriber(modid = KeepSmiling.MODID)
public final class KsEvents {
    private KsEvents() {}

    private static final Map<String, Long> LAST = new HashMap<>();
    private static int tormentorCooldown;
    private static long tormentorLastDay = -1;
    private static long smilerNextDay = -1;
    private static long dayNow;

    /** true cada 'ticks' ticks por jugador y clave (devuelve y registra). */
    private static boolean due(ServerLevel level, ServerPlayer p, String key, long ticks) {
        long now = level.getGameTime();
        String k = p.getUUID() + key;
        long last = LAST.getOrDefault(k, 0L);
        if (now - last >= ticks) { LAST.put(k, now); return true; }
        return false;
    }

    private static boolean active(ServerLevel level, KsType t) {
        return !level.getEntities(KeepSmiling.TYPES.get(t).get(), e -> true).isEmpty();
    }

    private static <T extends KsEntity> T spawn(ServerLevel level, KsType t, Vec3 pos) {
        @SuppressWarnings("unchecked")
        T e = (T) KeepSmiling.TYPES.get(t).get().create(level);
        if (e == null) return null;
        e.moveTo(pos.x, pos.y, pos.z, level.random.nextFloat() * 360F, 0);
        level.addFreshEntity(e);
        return e;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        long t = level.getGameTime();
        dayNow = Ks.day(level);

        if (t % 20 == 0) {
            for (ServerPlayer p : Ks.players(level)) {
                if (!Ks.isSurvival(p) || p.isCreative()) continue;
                try {
                    maybeSpawnChaser(level, p, KsType.STALKER);
                    maybeSpawnChaser(level, p, KsType.LUSTER);
                } catch (Exception ex) { /* chunk sin cargar */ }
            }
            tormentorTick(level);
        }
        if (t % 100 == 0) {
            for (ServerPlayer p : Ks.players(level)) {
                if (!Ks.isSurvival(p)) continue;
                try {
                    maybeSpawnSmiler(level, p);
                    maybeSpawnStare(level, p);
                } catch (Exception ex) { /* chunk sin cargar */ }
            }
        }
    }

    // ---------------------------------------------------------------- stalker y luster
    private static void maybeSpawnChaser(ServerLevel level, ServerPlayer p, KsType type) {
        String key = type.id;
        if (!due(level, p, key + "_probe", 40)) return;
        if (active(level, type)) return;
        boolean cave = Ks.isCave(level, p.position());
        boolean nature = Ks.canSeeSky(level, p.position());
        if (!cave && !nature) return;
        long interval = cave ? 600 : Ks.isDay(level) ? 2400 : 1200;
        if (!due(level, p, key, interval)) return;
        if (level.random.nextDouble() > 0.35) return;
        Vec3 pos = Ks.behindPlayerSpot(level, p, 12, 24);
        if (pos == null) pos = Ks.ringSpot(level, p, 12, 26, 5);
        if (pos == null) return;
        KsEntity e = spawn(level, type, pos);
        if (e instanceof LusterEntity l) l.immediate = true;
    }

    // ---------------------------------------------------------------- tormentor (maximo una vez por dia)
    private static void tormentorTick(ServerLevel level) {
        if (active(level, KsType.TORMENTOR)) return;
        if (++tormentorCooldown < 100) return;
        tormentorCooldown = 0;
        long day = Ks.day(level);
        if (day <= tormentorLastDay) return;
        long tod = Ks.timeOfDay(level);
        boolean morning = tod < 3000, daytime = tod >= 3000 && tod < 9000, afternoon = tod >= 9000 && tod < 12000;
        boolean sunsetNight = tod >= 12000 && tod <= 23000;
        for (ServerPlayer p : Ks.players(level)) {
            if (!Ks.isSurvival(p)) continue;
            boolean inCave = Ks.isCave(level, p.position());
            boolean can = false;
            double r = level.random.nextDouble();
            if (inCave) can = r < 0.70;
            else if (morning || daytime || afternoon) can = r < 0.05;
            else if (sunsetNight) can = r < 0.50;
            if (!can) continue;
            Vec3 pos = Ks.ringSpot(level, p, 25, 40, 5);
            if (pos == null) continue;
            TormentorEntity e = spawn(level, KsType.TORMENTOR, pos);
            if (e == null) continue;
            e.setTarget(p);
            Ks.play(p, "tormentor_wait");
            tormentorLastDay = day;
            break;
        }
    }

    // ---------------------------------------------------------------- smiler (noche, superficie)
    private static void maybeSpawnSmiler(ServerLevel level, ServerPlayer p) {
        if (!due(level, p, "smiler", 20 * 34)) return;
        if (!Ks.isNightOrSunset(level) || active(level, KsType.SMILER)) return;
        if (level.random.nextDouble() > 0.15) return;
        long day = Ks.day(level);
        if (day < smilerNextDay) return;
        double a = level.random.nextDouble() * Math.PI * 2, d = 24 + level.random.nextDouble() * 24;
        int x = (int) Math.floor(p.getX() + Math.cos(a) * d), z = (int) Math.floor(p.getZ() + Math.sin(a) * d);
        if (!level.hasChunkAt(new BlockPos(x, 64, z))) return;
        Vec3 pos = new Vec3(x + 0.5, Ks.surfaceY(level, x, z), z + 0.5);
        if (spawn(level, KsType.SMILER, pos) != null) {
            Ks.playAll(level, "smiler_spawn");
            smilerNextDay = day + 1 + level.random.nextInt(3);
        }
    }

    // ---------------------------------------------------------------- stare (cuevas o bosque de noche)
    private static boolean nearTree(ServerLevel level, Vec3 pos, int radius) {
        int px = (int) Math.floor(pos.x), py = (int) Math.floor(pos.y), pz = (int) Math.floor(pos.z);
        for (int x = px - radius; x <= px + radius; x += 3)
            for (int z = pz - radius; z <= pz + radius; z += 3)
                for (int y = py - 2; y <= py + 5; y += 2) {
                    BlockPos bp = new BlockPos(x, y, z);
                    if (!level.hasChunkAt(bp)) continue;
                    String n = Ks.name(level.getBlockState(bp));
                    if (n.contains("log") || n.contains("leaves")) return true;
                }
        return false;
    }

    private static void maybeSpawnStare(ServerLevel level, ServerPlayer p) {
        if (!due(level, p, "stare", 20 * 60)) return;
        if (active(level, KsType.STARE)) return;
        boolean cave = Ks.isCave(level, p.position());
        boolean forestNight = Ks.isNight(level) && nearTree(level, p.position(), 12);
        if (!cave && !forestNight) return;
        if (level.random.nextDouble() > 0.48) return;
        Vec3 pos = null;
        for (int i = 0; i < 32 && pos == null; i++) {
            Vec3 c = Ks.ringSpot(level, p, 16, 28, 0);
            if (c != null && (cave || nearTree(level, c, 12))) pos = c;
        }
        if (pos == null) return;
        StareEntity e = spawn(level, KsType.STARE, pos);
        if (e != null) e.setTarget(p);
    }

    // ---------------------------------------------------------------- limpieza al morir
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p) || !(p.level() instanceof ServerLevel level)) return;
        for (KsType t : new KsType[]{KsType.STALKER, KsType.LUSTER, KsType.TORMENTOR, KsType.SMILER, KsType.STARE}) {
            List<? extends KsEntity> list = level.getEntities(KeepSmiling.TYPES.get(t).get(), e -> true);
            for (KsEntity e : list) e.discard();
        }
    }
}
