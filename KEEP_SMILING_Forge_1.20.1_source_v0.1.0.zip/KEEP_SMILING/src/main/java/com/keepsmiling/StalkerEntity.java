package com.keepsmiling;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/**
 * Stalker (stalker_ai.js): espera quieto; si lo miras (a menos de 40 bloques) suena watch + music, 2 s despues
 * grita y te persigue (teletransportandose 0.55 bloques por tick y rompiendo muros) durante 34 s.
 * Si pasan 2 min sin que lo mires, desaparece.
 */
public class StalkerEntity extends KsEntity {
    private enum S { WAITING, WATCHING, CHASING }

    private S state = S.WAITING;
    private int waitTimer, chaseTimer, effectTimer, lifeTimer, notLookedTimer, watchStart;
    private boolean triggered;

    public StalkerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, KsType.STALKER);
    }

    @Override
    protected void serverTick(ServerLevel level) {
        ServerPlayer target = closest(level, 4096);
        if (target == null) return;

        // 2 s despues de verlo: empieza la persecucion
        if (state == S.WATCHING && tickCount - watchStart >= 40) {
            state = S.CHASING;
            Ks.play(target, "stalker_scream");
            setVariant(1);
            if (Ks.isSurvival(target)) Ks.darkness(target, 100, 0);
        }
        if (state == S.CHASING) {
            chaseStep(level, target, 0.55, true);
            contactDamage(target, 8.0F, 1.6);
        }
        if (tickCount % 5 != 0) return; // el resto corre cada 5 ticks, como el bucle del addon

        double minDist = distanceTo(target);
        boolean survival = Ks.isSurvival(target);

        if (state == S.CHASING) {
            lifeTimer += 5;
            if (lifeTimer >= 680) { // la musica termina: se va
                target.removeEffect(MobEffects.DARKNESS);
                discard();
                return;
            }
        }
        boolean canSee = Ks.hasLineOfSight(target, this, 1.5, true);

        if (state == S.WAITING && minDist <= 40) {
            waitTimer += 5;
            if (!canSee) {
                notLookedTimer += 5;
                if (notLookedTimer >= 100) { Ks.play(target, "stalker_wait"); notLookedTimer = 0; }
            } else notLookedTimer = 0;

            if (canSee && !triggered) {
                triggered = true;
                state = S.WATCHING;
                watchStart = tickCount;
                Ks.play(target, "stalker_watch");
                Ks.play(target, "stalker_music");
                Ks.actionBar(target, "§cDO NOT HIDE JUST RUN !");
            }
            if (waitTimer >= 2400 && !canSee) { discard(); return; }
        }

        if (state == S.CHASING) {
            Ks.actionBar(target, "§cDO NOT HIDE JUST RUN !");
            if (chaseTimer <= 0) { Ks.play(target, "stalker_chase"); chaseTimer = 19; } else chaseTimer--;
            if (survival) {
                if (effectTimer <= 0) { Ks.darkness(target, 100, 0); effectTimer = 6; } else effectTimer--;
            }
        }
    }

    @Override
    protected void onGone(ServerLevel level) {
        if (state != S.WAITING) {
            for (ServerPlayer p : level.players()) p.removeEffect(MobEffects.DARKNESS);
        }
        Ks.stopAll(level, "stalker_wait", "stalker_watch", "stalker_music", "stalker_chase");
    }
}
