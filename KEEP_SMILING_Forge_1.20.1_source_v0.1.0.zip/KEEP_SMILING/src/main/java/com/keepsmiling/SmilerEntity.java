package com.keepsmiling;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

import java.util.UUID;

/**
 * Smiler (smiler.js): aparece de noche en la superficie y se queda quieto. Mientras lo miras suena smiler_look, te
 * ralentiza y pone "DONT LOOK AT HIM"; si lo miras ~2.5 s (o se te acerca a 3.5 bloques) te persigue 67 s a 0.88 bloques por tick.
 */
public class SmilerEntity extends KsEntity {
    private boolean chase, beingLooked;
    private int lookTicks, soundTimer, chaseTimer;
    private UUID targetId;

    public SmilerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, KsType.SMILER);
    }

    private ServerPlayer targetOr(ServerLevel level) {
        ServerPlayer t = targetId == null ? null : level.getServer().getPlayerList().getPlayer(targetId);
        return t != null && t.isAlive() ? t : closest(level, 4096);
    }

    private void cameraEffects(ServerPlayer p) {
        Ks.effect(p, MobEffects.MOVEMENT_SLOWDOWN, 10, 4);
        Ks.effect(p, MobEffects.MOVEMENT_SPEED, 10, 5);
    }

    private void clearEffects(ServerPlayer p) {
        p.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        p.removeEffect(MobEffects.MOVEMENT_SPEED);
    }

    private boolean looking(ServerPlayer p) {
        return Ks.hasLineOfSight(p, this, 1.5, false) && Ks.lookDot(p, this, 1.5) > 0.35;
    }

    @Override
    protected void serverTick(ServerLevel level) {
        if (chase) {
            ServerPlayer t = targetOr(level);
            if (t != null) {
                chaseStep(level, t, 0.88, true);
                contactDamage(t, 8.0F, 1.6);
            }
        }
        if (tickCount % 2 != 0) return;

        if (!chase) {
            ServerPlayer lookingPlayer = null, closestPlayer = closest(level, 4096);
            double minDist = closestPlayer == null ? 0 : Math.hypot(closestPlayer.getX() - getX(), closestPlayer.getZ() - getZ());
            for (ServerPlayer p : Ks.players(level)) if (looking(p)) lookingPlayer = p;
            ServerPlayer target = lookingPlayer != null ? lookingPlayer : closestPlayer;
            if (target == null) return;
            targetId = target.getUUID();

            if (looking(target)) {
                lookTicks++;
                if (!beingLooked || soundTimer <= 0) {
                    Ks.play(target, "smiler_look");
                    beingLooked = true;
                    soundTimer = 40;
                } else soundTimer -= 2;
                cameraEffects(target);
                Ks.actionBar(target, "§cDONT LOOK AT HIM");
                if (Ks.isSurvival(target) && (lookTicks >= 50 || minDist <= 3.5)) startChase(level, target);
            } else {
                if (beingLooked) {
                    Ks.stop(target, "smiler_look");
                    clearEffects(target);
                    beingLooked = false;
                    soundTimer = 0;
                    Ks.actionBar(target, "");
                }
                lookTicks = 0;
            }
        } else {
            chaseTimer += 2;
            if (chaseTimer >= 1340) { // 67 s
                discard();
                return;
            }
            ServerPlayer closest = closest(level, 4096);
            ServerPlayer target = targetOr(level);
            if (closest != null && distanceTo(closest) <= 2.5) { targetId = closest.getUUID(); target = closest; }
            if (target == null) return;
            for (ServerPlayer p : Ks.players(level)) if (Ks.isSurvival(p)) Ks.darkness(p, 40, 1);
            Ks.actionBar(target, "§cGood luck...");
        }
    }

    private void startChase(ServerLevel level, ServerPlayer player) {
        chase = true;
        chaseTimer = 0;
        Ks.stopAll(level, "smiler_look");
        clearEffects(player);
        Ks.playAll(level, "smiler_chase");
        Ks.playAll(level, "smiler_music");
    }

    @Override
    protected void onGone(ServerLevel level) {
        Ks.stopAll(level, "smiler_look", "smiler_music", "smiler_chase");
        for (ServerPlayer p : level.players()) {
            clearEffects(p);
            if (chase) p.removeEffect(MobEffects.DARKNESS);
            if (chase || beingLooked) Ks.actionBar(p, "");
        }
    }
}
