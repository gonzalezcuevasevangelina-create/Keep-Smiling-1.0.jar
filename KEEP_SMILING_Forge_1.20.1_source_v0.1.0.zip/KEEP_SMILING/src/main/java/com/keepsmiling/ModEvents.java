package com.keepsmiling;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = KeepSmiling.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        for (KsType t : KsType.values()) {
            event.put(KeepSmiling.TYPES.get(t).get(), KsEntity.createAttributes().build());
        }
    }
}
