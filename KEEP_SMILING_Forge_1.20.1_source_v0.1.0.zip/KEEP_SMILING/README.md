# Keep Smiling — port a Forge 1.20.1 (ADELANTO)

Port del addon de Bedrock **Keep Smiling** (autor original: **Azk873**) a Forge 1.20.1 (47.x). El `.jar` se llama
`Keep Smiling-0.1.0.jar`.

## Estado del port

| Entidad | Estado |
|---|---|
| `stalker` | portado: espera, te ve, grita y persigue (rompe muros), oscuridad, sonidos, 34 s de persecución |
| `luster` | portado: se activa de lejos (≤150 bloques) o al aparecer, persigue, visión nocturna, 41 s |
| `tormentor` | portado: WAIT → MUSIC → WARN → CHASE (48 s), una vez al día |
| `smiler` | portado: de noche, "DONT LOOK AT HIM", ralentiza al mirarlo, persecución de 67 s |
| `stare` | portado: cuevas / bosque de noche, 50 % se va, si no persigue 90 s; la luz lo espanta |
| resto (door_stalker, window_stalker, stalk_window, stalker_bed, stalker_miner, bipedal_*, influence, error_entity, tormentor_door, muñecos) | **solo registradas** (sprite, huevo, sonidos y texturas), todavía sin comportamiento |

También: los 5 muñecos (jester, anderdingus, smiler, bipedal, tormentor) con su receta (p. ej. pluma sobre lana verde),
53 sonidos y todas las texturas del addon original. Aparición natural como en el addon (stalker/luster en superficie y cuevas,
tormentor 1 vez al día, smiler de noche, stare en cuevas/bosque nocturno).

## No portado todavía / diferencias
- Las 20 entidades "solo registradas" (ver tabla). Se pueden pedir por grupos.
- Menú para elegir muñeco al entrar al mundo, `camerashake` (no existe en Java) y el nombre de pack.
- Todo está sin probar en el juego: está escrito sin poder compilarlo, así que el primer build puede marcar algún nombre.

## Compilar el .jar con GitHub (sin instalar nada)
1. Crea una cuenta en github.com y un repositorio nuevo (sin README).
2. Descomprime este zip y sube **todo su contenido** (incluida la carpeta oculta `.github`) al repositorio
   (*uploading an existing file*, o GitHub Desktop si no sube `.github`).
3. Abre la pestaña **Actions** → "Build Keep Smiling" (tarda 3–6 min; si hace falta, **Run workflow**).
4. Con la marca verde, baja el artefacto **KeepSmiling-jar** (zip con `Keep Smiling-0.1.0.jar`).
5. Copia el `.jar` a `.minecraft/mods` con Minecraft 1.20.1 + Forge 47.x.
Si sale una X roja, copia las líneas con `error:` del paso *Run gradle build* y mándamelas.

## Compilar en local
JDK 17 + Gradle 8.1.1: `gradle build` → `build/libs/Keep Smiling-0.1.0.jar`.

## Créditos
Addon original de Bedrock: Azk873. Port a Forge: hecho a petición del usuario, con permiso del autor original.
